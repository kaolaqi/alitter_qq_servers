<template>
  <div class="timer-picker-box">
    <el-date-picker
      v-model="timeValue"
      :type="dateType || 'daterange'"
      :default-time="['00:00:00', '23:59:59']"
      align="left"
      size="mini"
      start-placeholder="开始日期"
      end-placeholder="结束日期"
      :picker-options="pickerOptions"
      :value-format="valueFormat||''"
      @change="changeTime"
    />
  </div>
</template>

<script>
// import moment from 'moment'

/**
     * @Author	limaoquan
     * @Time	2018-08-29
     *
     * @Author  limaoquan
     * @Time    2018-09-25 更新控制日期空间选择范围
     *
     * @props: [
     *      //日期类型格式
     *      dateType: default daterange
     * 		//默认日期
     *   	dafaultDay: [startDate(Date),endDate(Date)]
     *      //多少天之前的日期禁用
     *      previouDays: Number
     *      //多少天之后的日期禁用
     *      afterDays: Number
     * ]
     *
     * @ $emit回调函数
     * 		//触发父组件里 时间选择被改变时间
     *   	changeTime:{
     *			injection:{
     *				params1: 新的 arrays = [startDate(Date),endDate(Date)]
     *			}
     *		}
     *
     */

export default {
  name: 'BaseTimePicker',
  props: ['dateType', 'dafaultDay', 'valueFormat', 'previouDays', 'afterDays'],
  data() {
    return {
      timeValue: this.dafaultDay || '',
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick(picker) {
            const end = new Date(new Date().setHours(23, 59, 59, 999))
            const start = new Date(new Date().setHours(0, 0, 0, 0))
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三天',
          onClick(picker) {
            const end = new Date(new Date().setHours(23, 59, 59, 999))
            const start = new Date(new Date().setHours(0, 0, 0, 0))
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 3)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一周',
          onClick(picker) {
            const end = new Date(new Date().setHours(23, 59, 59, 999))
            const start = new Date(new Date().setHours(0, 0, 0, 0))
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近一个月',
          onClick(picker) {
            const end = new Date(new Date().setHours(23, 59, 59, 999))
            const start = new Date(new Date().setHours(0, 0, 0, 0))
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }, {
          text: '最近三个月',
          onClick(picker) {
            const end = new Date(new Date().setHours(23, 59, 59, 999))
            const start = new Date(new Date().setHours(0, 0, 0, 0))
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
            picker.$emit('pick', [start, end])
          }
        }]
      }
    }
  },
  watch: {
    dafaultDay() {
      this.timeValue = this.dafaultDay || ''
    }
  },
  created() {
    var self = this
    // 禁用日期选项配置
    self.pickerOptions.disabledDate = function(time) {
      if (self.previouDays !== undefined && self.afterDays === undefined) {
        return time.getTime() < Date.now() - (self.previouDays + 1) * 8.64e7
      } else if (self.previouDays === undefined && self.afterDays !== undefined) {
        return time.getTime() > Date.now() + self.afterDays * 8.64e7
      } else if (self.previouDays !== undefined && self.afterDays !== undefined) {
        return time.getTime() < Date.now() - (self.previouDays + 1) * 8.64e7 || time.getTime() > Date.now() + self.afterDays * 8.64e7
      }
    }
  },
  methods: {
    changeTime: function() {
      this.$emit('changeTime', this.timeValue)
    }
  }
}
</script>
<style
    scoped
    lang="scss"
>
    @import './index.scss';
</style>
