<!--
 * @Description: 公共表格组件
 * @Author: limaoquan
 * @Date: 2019-10-02 08:48:01
 * @LastEditTime: 2019-10-04 08:52:36
 * @LastEditors: Please set LastEditors
 -->
<template>
  <div class="common-table">
    <el-table
      :border="!noBorder"
      :data="tableData || (tableContent?tableContent.rows:[])"
      stripe
      :style="tableWidth || '100%'"
      :cell-style="cellStyle"
      :cell-class-name="linkStyle"
      :default-sort="defaultSort"
      @sort-change="$emit('sort-change',$event)"
      @selection-change="handleSelectionChange"
      @cell-click="handleCellClick"
    >

      <el-table-column v-if="hasExpand" type="expand">
        <template slot-scope="props">
          <slot :props="props" />
        </template>
      </el-table-column>

      <!-- 表头数据 -->
      <template v-for="item in tableHeaderList">
        <el-table-column
          v-if="!isFilterRow || (isFilterRow && item.visible)"
          :key="item.prop"
          :prop="item.prop"
          :label="item.name"
          :class-name="item.className"
          :formatter="getFormat"
          :width="item.width"
          :sortable="item.sortable?true:false"
          :sort-orders="item.sortOrders?item.sortOrders:[]"
          align="center"
        />
      </template>
      <!-- <template v-for="item in (slotConfig || [])"> -->
      <el-table-column
        v-for="item in (slotConfig || [])"
        :key="'Column'+item.name"
        :label="item.name"
        align="center"
        :width="item.width"
        :fixed="item.buttonFixed?item.buttonFixed:false"
      >
        <template slot-scope="scope">
          <slot
            :name="item.soltName"
            :scope="scope"
          />
        </template>
      </el-table-column>
      <!-- </template> -->

      <!-- table操作按钮 -->
      <tableButton
        v-if="Array.isArray(buttonConfig) && buttonConfig.length > 0"
        :button-config="buttonConfig"
        @onHandleButton="onHandleButton"
      />
    </el-table>
    <!-- 表格组件自带分页信息 wangkai 2018-08-29 chhange  -->
    <el-pagination
      v-if="!noPagination"
      class="pagination"
      :page-sizes="pageArray"
      :page-size="pageSize || (tableContent?tableContent.pageSize:0)"
      layout="total, sizes, prev, pager, next, jumper"
      :total="totalCount || (tableContent?tableContent.totalCount:0)"
      :current-page="pageNo || (tableContent?tableContent.pageNo:0)"
      @size-change="pageSizeChange"
      @current-change="currentChange"
    />
  </div>
</template>

<script>
import tableButton from './tableButton.vue'

export default {
  name: 'CommonTable',
  components: {
    tableButton
  },
  props: {
    // 表头配置
    tableHeader: Array,
    // 表格内容：带分页信息和data数据的对象||数据列表数组
    tableContent: [Array, Object],
    // 表格排序
    defaultSort: Object,
    // 是否自定义显示列
    isFilterRow: Boolean,
    // 表格数据
    tableData: Array,
    // 按钮配置
    buttonConfig: Array,
    // solt按钮
    slotConfig: Array,
    // 表格宽度或宽度百分比
    tableWidth: String,
    // 表格高度或高度百分比
    tableHeight: String,
    // 表格数据转换函数
    getFormat: Function,
    // 表格数据样式函数
    cellStyle: Function,
    // 表格行样式
    linkStyle: Function,
    // 是否不带分页，默认带分页
    noPagination: Boolean,
    // 当前分页
    pageNo: Number,
    // 当前分页大小
    pageSize: Number,
    // 分页总大小
    totalCount: Number,
    // expandProps: Object
    hasExpand: Boolean,
    noBorder: Boolean
  },
  data() {
    return {
      // 默认表格大小
      pageArray: [10, 20, 50, 100],
      // 表头
      tableHeaderList: []
    }
  },
  mounted() {
    // 初始化表头
    if (this.isFilterRow && this.$refs.filterHeader) {
      this.tableHeaderList = this.$refs.filterHeader.$initFilterRow()
    } else {
      this.tableHeaderList = this.tableHeader
    }
    // 判断是否存在自定义pageArray
    if (Array.isArray(this.customPageArray) && this.customPageArray.length > 0) {
      this.pageArray = this.customPageArray
    }
  },
  methods: {
    // 分页条数修改函数
    pageSizeChange() {
      var arg = Array.from(arguments)
      this.$emit('pageSizeChange', ...arg)
    },
    // 分页页面修改函数
    currentChange() {
      var arg = Array.from(arguments)
      this.$emit('currentChange', ...arg)
    },
    // 行点击操作
    handleCellClick() {
      var arg = Array.from(arguments)
      this.$emit('handleCellClick', ...arg)
    },
    // 内部选择的项目数组函数
    handleSelectionChange(val) {
      this.multipleSelection = val
    },

    /** *******************************************/
    // 表格操作栏触发事件
    onHandleButton(row, eventMethod) {
      if (typeof eventMethod === 'string') {
        this.$emit(eventMethod, row)
      }
    }
  }
}
</script>

<style
    lang="scss"
    scoped
>
    @import "./index.scss";
</style>
