<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-10-02 10:32:02
 * @LastEditTime: 2019-10-02 13:38:22
 * @LastEditors: Please set LastEditors
 -->
<template>
  <div>
    <el-table-column
      v-for="itemArray in buttonConfig"
      v-if="Array.isArray(buttonConfig) && buttonConfig.length !== 0"
      :key="'Column'+itemArray.name"
      :label="itemArray.name"
      align="center"
      :width="itemArray.width?itemArray.width:80*itemArray.list.length"
      :fixed="itemArray.buttonFixed?itemArray.buttonFixed:'right'"
    >
      <template slot-scope="scope">
        <span v-for="item in itemArray.list">
          <!-- 插槽按钮 -->
          <el-button
            v-if="!item.isLink &&
              ((item.onJudgeShow && typeof item.onJudgeShow === 'function')?
                item.onJudgeShow(scope.row) : true )"
            :key="item.eventMethod"
            size="mini"
            :icon="item.icon"
            :type="item.type || 'primary'"
            :disabled="item.onDisabled?item.onDisabled(scope.row):false"
            @click="click(scope.row,item.eventMethod)"
          >
            {{ typeof item.name === 'function'? item.name(scope.row): item.name }}
          </el-button>
          <!-- 跳转link -->
          <router-link
            v-if="item.isLink && item.onLink &&
              ((item.onJudgeShow && typeof item.onJudgeShow === 'function')?
                item.onJudgeShow(scope.row) : true )"
            :class="item.className?item.className:''"
            :to="item.onLink(scope.row)"
            :target="item.target?item.target:'_self'"
          >
            {{ typeof item.text === 'function'? item.text(scope.row): item.text }}
          </router-link>
        </span>
      </template>
    </el-table-column>
  </div>
</template>

<script>
export default {
  name: 'QncxTableButton',
  props: {
    buttonConfig: Array
  },
  data() {
    return {
    }
  },
  methods: {
    // 表格操作栏触发事件
    click(row, eventMethod) {
      if (typeof eventMethod === 'string') {
        this.$emit('onHandleButton', row, eventMethod)
      }
    }
  }
}
</script>

<style lang="scss">
	@import './index.scss'
</style>

