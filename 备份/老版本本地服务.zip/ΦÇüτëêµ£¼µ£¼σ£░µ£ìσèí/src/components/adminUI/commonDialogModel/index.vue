<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-10-02 15:06:42
 * @LastEditTime: 2019-10-02 16:35:10
 * @LastEditors: Please set LastEditors
 -->

<template>
  <div class="component-dialog">
    <!-- 共用dialog组件 -->
    <el-dialog
      :title="dialogConfig.title || ''"
      :visible.sync="dialogConfig.showFlag"
      :width="dialogConfig.width || '50%'"
      :center="dialogConfig.center || false"
      :top="dialogConfig.top || '15vh'"
      :modal-append-to-body="dialogConfig.modalAppendToBody || false"
      :before-close="cancel"
    >
      <slot />
      <div v-if="!dialogConfig.isHideDialogFooter" class="dialog-footer">
        <slot name="footer-btn" />
        <el-button
          type="primary"
          @click="confirm"
        >
          {{ dialogConfig.comfirmText || '确 定' }}
        </el-button>
        <el-button
          @click="cancel"
        >
          {{ dialogConfig.cancelText || '取 消' }}
        </el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

export default {
  name: 'CommonDialogModel',
  props: {
    dialogConfig: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  methods: {
    cancel() {
      this.$emit('cancel')
    },
    confirm() {
      this.$emit('confirm')
    }
  }
}
</script>

<style scoped lang="scss">
	@import './index.scss';
</style>
