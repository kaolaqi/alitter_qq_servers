<!--
 * @Description: 系统公告头部筛选栏
 * @Author: limaoquan
 * @Date: 2019-09-30 11:52:32
 * @LastEditTime: 2019-10-02 09:29:39
 * @LastEditors: limaoquan
 -->
<template>
  <div>
    <!-- 筛选过滤组件 -->
    <template v-for="(item,index) in filterData">

      <!-- 文本框输入类型 -->
      <span
        v-if="item.type === 'text'"
        :key="index"
        class="item"
      >
        <label v-if="item.label">{{ item.label }}：</label>
        <el-input
          v-model.trim="item.value"
          type="text"
          :placeholder="item.holder || ''"
          :style="{'width': item.width + 'px'}"
          @change="passData(item.fieldName, $event)"
        />
      </span>

      <!-- 数字框输入类型 -->
      <span
        v-else-if="item.type === 'number'"
        :key="index"
        class="item"
      >
        <label v-if="item.label">{{ item.label }}：</label>
        <el-input
          v-model="item.value"
          width="200px"
          type="number"
          :placeholder="item.holder || ''"
          :style="{'width': item.width + 'px'}"
          @change="passData(item.fieldName, $event)"
        />
      </span>

      <!-- 下拉选项框类型 -->
      <span
        v-else-if="item.type === 'select'"
        :key="index"
        class="item"
      >
        <label v-if="item.label">{{ item.label }}：</label>
        <el-select
          v-model="item.value"
          placeholder="请选择"
          size="mini"
          :style="{'width': item.width + 'px'}"
          @change="passData(item.fieldName, $event)"
        >
          <el-option
            v-for="value in item.options"
            :key="value.value"
            :label="value.label"
            :value="value.value"
          />
        </el-select>
      </span>

      <!-- 时间段选择类型 -->
      <span
        v-else-if="item.type === 'timePicker'"
        :key="index"
        class="item time-picker"
      >
        <label v-if="item.label">{{ item.label }}：</label>
        <time-picker
          :date-type="item.dateType"
          :dafault-day="item.value"
          :previou-days="item.previouDays"
          :after-days="item.afterDays"
          :value-format="item.valueFormat"
          @changeTime="item.value = $event, passData(item.fieldName[0], ($event && $event[0]) || undefined), passData(item.fieldName[1], ($event && $event[1]) || undefined)"
        />
      </span>

      <!-- 操作按钮绑定事件列表 -->
      <span
        v-for="value in item.data"
        v-else-if="item.type === 'button'"
        :key="value.index"
        class="item"
      >
        <el-button
          :type="value.type"
          :icon="value.icon"
          @click="click(value.event)"
        >
          {{ value.value }}
        </el-button>
      </span>

      <!-- 不支持类型 -->
      <span
        v-else
        :key="index"
        class="item"
      >不支持类型</span>
    </template>
  </div>
</template>

<script>
/**
 * @Author	limaoquan
 * @Time	2019-09-30
 * @porps
 *  filterData: Array[ object = {
 *    筛选类型 type: string [
 *      text：文本输入框，
 *      number：数字输入框，
 *      select：下拉选项框类型，
 *      button: 按钮列表
 *    ],
 *    筛选框类型说明 label: string,
 *    筛选框绑定值 value: '',
 *    筛选框placeholder holder: '请输入手机号',
 *    筛选框宽度 width: number | 200,
 *    select下拉筛选框数据:
 *      data:[object = {
 *        value: null | number | string, 	//选项key
 *        label: string   				//选项名
 *      }...]
 *    button操作:
 *      {
 *        type: 'button',
 *        data:[object = {
 *          value: string, 	//按钮文本
 *          type:  string,  //el-button的type
 *          icon:  string,  //按钮图标名称
 *          event: string   //回调事件名称
 *        }...]
 *      }
 *   }]
 */

import timePicker from '../base/timePicker/index.vue'

export default {
  name: 'FilterHeader',
  components: {
    timePicker
  },
  props: {
    // 自定义筛选栏配置信息
    filterData: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      payload: {}
    }
  },
  mounted() {
    var self = this
    // 重新挂载是缓存之前的参数值，回传键值对
    for (let i = 0; i < self.filterData.length; i++) {
      const item = self.filterData[i]
      if (item.type === 'text' || item.type === 'number' || item.type === 'select') {
        self.passData(item.fieldName, item.value)
      } else if (item.type === 'timePicker') {
        const value = item.value
        self.passData(item.fieldName[0], (value && value[0]) || null, item.fieldName[0])
        self.passData(item.fieldName[1], (value && value[1]) || null, item.fieldName[1])
      }
    }
  },
  methods: {
    // 配置查询的操作按钮，固定事件名称
    click(eventName) {
      this.$emit(eventName)
    },
    // 接收子组件传递参数 -- 键值对对象
    receiveData(data, fieldNames) {
      var payload = this.payload
      if (typeof data === 'object') {
        // 重置多输入类型生成的键值对
        if (typeof fieldNames === 'string') {
          for (const fieldName in payload) {
            if (payload.hasOwnProperty(fieldName) && fieldNames.indexOf(fieldName) !== -1) {
              delete payload[fieldName]
            }
          }
        }
        Object.assign(this.payload, data)
      }
      this.$emit('passData', payload)
    },
    // 普通类型筛选框回传键值对对象
    passData(fieldName, value) {
      var payload = {}
      if (value !== '' || value !== undefined) {
        payload[fieldName] = value
      }
      this.receiveData(payload, fieldName)
    }
  }
}
</script>

<style
    lang="scss"
    scoped
>
    @import "./index.scss";
</style>
