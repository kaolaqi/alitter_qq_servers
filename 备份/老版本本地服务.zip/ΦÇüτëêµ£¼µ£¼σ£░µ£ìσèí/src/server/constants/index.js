
module.exports = {
  tokenSecret: 'asdasdfDfaecasdfqeqevdaASaas'
}
