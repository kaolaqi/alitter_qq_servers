const adminModel = require('./admin')
const clientModel = require('./client')

module.exports = {
  adminModel,
  clientModel
}
