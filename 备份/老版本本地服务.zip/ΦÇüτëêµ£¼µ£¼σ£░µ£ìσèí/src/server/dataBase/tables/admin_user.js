const utility = require('utility')
const Sequelize = require('sequelize')
const sequelize = require('../init')

// 初始化数据库的user表
const backstageUserAdmin = sequelize.define('backstage_user', {
  username: {
    type: Sequelize.STRING,
    allowNull: false,
    comment: '这是一个包含注释的列名'
  },
  password: {
    type: Sequelize.STRING,
    allowNull: false
  },
  email: {
    type: Sequelize.STRING,
    allowNull: false
  },
  key: {
    type: Sequelize.STRING,
    allowNull: false
  },
  avatar: {
    type: Sequelize.STRING,
    allowNull: true
  },
  role: {
    type: Sequelize.STRING,
    allowNull: false
  },
  status: {
    type: Sequelize.STRING,
    allowNull: false
  }
}, {
  indexes: [{
    unique: true,
    fields: ['username']
  }]
})

backstageUserAdmin.sync({
  force: false
}).then(() => {
  // 现在数据库中的 `backstage_user` 表对应于模型定义
  backstageUserAdmin.findOne().then(res => {
    if (!res) {
      console.log('即将创建backstage_user表')
      return backstageUserAdmin.create({
        username: 'admin',
        password: utility.sha256('123456'),
        role: 'super',
        email: 'admin_ad@qq.com',
        key: 'losekeylosepass',
        avatar: null,
        status: 'open'
      })
    } else {
      console.log('backstage_user表已经存在....')
    }
  }).catch(err => {
    throw Error('创建表backstage_user失败....' + err)
  })
})

module.exports = backstageUserAdmin
