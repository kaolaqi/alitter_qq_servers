const utility = require('utility')
const Sequelize = require('sequelize')
const sequelize = require('../init')
// const userFriendAdmin = require('./client_user_firend')
const userMessageAdmin = require('./client_user_message')

// 初始化数据库的user表
const clientUserAdmin = sequelize.define('client_user', {
  userId: {
    type: Sequelize.BIGINT,
    primaryKey: true,
    autoIncrement: true
  },
  mobile: {
    type: Sequelize.STRING,
    allowNull: false
  },
  nickname: {
    type: Sequelize.STRING,
    allowNull: false
  },
  sign: {
    type: Sequelize.STRING,
    allowNull: false,
    defaultValue: ''
  },
  avatar: {
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: 'http://localhost:8090/static/images/avatar.png'
    // defaultValue: 'http://192.168.1.4:8090/static/images/avatar.png'
  },
  password: {
    type: Sequelize.STRING,
    allowNull: false
  },
  status: {
    type: Sequelize.INTEGER,
    allowNull: false,
    comment: '用户账号状态：1|正常 2|冻结'
  }
}, {
  indexes: [{
    unique: true,
    fields: ['mobile']
  }]
})

// clientUserAdmin.belongsTo(userMessageAdmin, {
//   foreignKey: 'userId',
//   as: 'lastMessage'
// })
clientUserAdmin.belongsTo(userMessageAdmin, {
  foreignKey: 'userId',
  as: 'lastMessage'
})

clientUserAdmin.sync({
  force: false
}).then(() => {
  // 现在数据库中的 `client_user` 表对应于模型定义
  clientUserAdmin.findOne().then(res => {
    if (!res) {
      console.log('即将创建client_user 表')
      return clientUserAdmin.create({
        mobile: '18372649152',
        nickname: '系统客服',
        avatar: 'http://localhost:8090/static/images/avatar.png',
        password: utility.sha256('9527'),
        status: 1
      })
    } else {
      console.log('client_user表已经存在....')
    }
  }).catch(err => {
    throw Error('创建表client_user失败....' + err)
  })
})

module.exports = clientUserAdmin
