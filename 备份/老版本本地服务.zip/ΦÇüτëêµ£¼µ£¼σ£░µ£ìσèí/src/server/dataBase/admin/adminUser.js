const utility = require('utility')
const backstageUserAdmin = require('../tables/admin_user')

// 后台管理用户注册
const admin_register = ({
  username,
  password,
  role = 'normal',
  email,
  key,
  avatar = null,
  status = 'close'
}) => {
  password = utility.sha256(password)
  return backstageUserAdmin.create({
    username,
    password,
    role,
    email,
    key,
    avatar,
    status
  }).then(data => {
    if (!data) {
      return {
        statusCode: 404,
        message: 'fetch noting from database',
        result: null
      }
    } else {
      return {
        statusCode: 200,
        message: 'request success',
        result: data.username
      }
    }
  }).catch(e => {
    return {
      statusCode: 500,
      result: null,
      message: e.errors
    }
  })
}

// 后台管理用户登录
const admin_login = ({
  username,
  password
}) => {
  return backstageUserAdmin.findOne({
    where: {
      username: username
    }
  }).then(userInfo => {
    if (userInfo) {
      password = utility.sha256(password)
      if (userInfo.password === password) {
        return {
          statusCode: 200,
          message: userInfo.username + '账号登录成功！',
          data: {
            avatar: userInfo.avatar,
            email: userInfo.email,
            id: userInfo.id,
            key: userInfo.key,
            role: userInfo.role,
            status: userInfo.status,
            username: userInfo.username
          }
        }
      } else {
        return {
          statusCode: 202,
          message: '账号密码不正确。',
          result: null
        }
      }
    } else {
      return {
        statusCode: 201,
        message: username + '账号不存在。。。',
        result: null
      }
    }
  }).catch(e => {
    return {
      statusCode: 500,
      result: null,
      message: e.errors
    }
  })
}

// 获取后台管理用户信息
const admin_info = ({
  username
}) => {
  return backstageUserAdmin.findOne({
    where: {
      username: username
    }
  }).then(data => {
    if (data) {
      return {
        statusCode: 200,
        message: 'success',
        data: {
          avatar: data.avatar,
          email: data.email,
          id: data.id,
          key: data.key,
          role: data.role,
          status: data.status,
          username: data.username
        }
      }
    } else {
      return {
        statusCode: 201,
        message: username + '账号不存在。。。',
        result: null
      }
    }
  }).catch(e => {
    return {
      statusCode: 500,
      result: null,
      message: e.errors
    }
  })
}

// 删除指定用户
const admin_toogleUserStatus = ({
  id,
  status
}) => {
  return backstageUserAdmin.update({
    status
  }, {
    where: {
      id: +id
    }
  }).then(data => {
    if (data) {
      return {
        statusCode: 200,
        message: 'success',
        data: data
      }
    }
  }).catch(e => {
    return {
      statusCode: 500,
      result: null,
      message: e.errors
    }
  })
}

// 获取客户端用户列表
const admin_userList = ({
  page = 1,
  pageSize = 10,
  username = '',
  status = '',
  role = ''
}) => {
  var query = {}
  if (username) {
    query.username = username
  }
  if (status) {
    query.status = status
  }
  if (role) {
    query.role = role
  }
  return backstageUserAdmin.findAndCountAll({
    offset: (page - 1) * pageSize,
    limit: +pageSize,
    attributes: ['id', 'username', 'email', 'avatar', 'status', 'role', 'createdAt'],
    where: query
  }).then(data => {
    if (data) {
      return {
        statusCode: 200,
        message: 'success',
        data: data
      }
    }
  }).catch(e => {
    return {
      statusCode: 500,
      result: null,
      message: e.errors
    }
  })
}

module.exports = {
  admin_register,
  admin_login,
  admin_info,
  admin_toogleUserStatus,
  admin_userList
}
