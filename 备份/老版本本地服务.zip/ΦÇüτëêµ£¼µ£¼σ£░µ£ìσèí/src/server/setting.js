module.exports = {
  webSocketHost: '192.168.1.9',
  webSocketPort: 8050

  // webSocketHost: '172.18.15.75',
  // webSocketPort: 8050
}
