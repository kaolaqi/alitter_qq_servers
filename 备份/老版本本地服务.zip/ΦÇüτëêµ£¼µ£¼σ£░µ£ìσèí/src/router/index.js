import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

export const constantRoutes = [{
  path: '/login',
  name: 'Login',
  component: () => import('@/views/login/index'),
  meta: {
    title: '登录'
  },
  hidden: true
}, {
  path: '/register',
  name: 'Register',
  component: () => import('@/views/register/index'),
  meta: {
    title: '注册'
  },
  hidden: true
},
{
  path: '/404',
  component: () => import('@/views/404'),
  hidden: true
}, {
  path: '/',
  component: Layout,
  redirect: '/index',
  children: [{
    path: 'index',
    name: 'Index',
    hidden: true,
    component: () => import('@/views/index/index'),
    meta: {
      title: '首页',
      icon: 'dashboard'
    }
  }]
}, {
  path: '/userAdmin',
  component: Layout,
  redirect: '/userAdmin/userList',
  name: 'AserAdmin',
  meta: {
    title: '用户管理',
    icon: 'example'
  },
  children: [{
    path: 'userList',
    name: 'UserList',
    component: () => import('@/views/userAdmin/userList'),
    meta: {
      title: '用户列表'
    }
  },
  {
    path: 'userAlbum',
    name: 'UserAlbum',
    component: () => import('@/views/userAdmin/userAlbum'),
    meta: {
      title: '用户相册'
    }
  }
  ]
},
{
  path: '/systemAdmin',
  component: Layout,
  redirect: '/systemAdmin/systemUserList',
  name: 'SystemAdmin',
  meta: {
    title: '系统管理',
    icon: 'example'
  },
  children: [{
    path: 'systemUserList',
    name: 'SystemUserList',
    component: () => import('@/views/systemAdmin/systemUserList'),
    meta: {
      title: '管理员列表'
    }
  }, {
    path: 'systemLoginList',
    name: 'SystemLoginList',
    component: () => import('@/views/systemAdmin/systemLoginList'),
    meta: {
      title: '日志列表'
    }
  }]
},
// 404 page must be placed at the end !!!
{
  path: '*',
  redirect: '/404',
  hidden: true
}
]

const createRouter = () => new Router({
  mode: 'history', // require service support
  scrollBehavior: () => ({
    y: 0
  }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
