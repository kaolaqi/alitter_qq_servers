import request from '@/utils/request'

// 系统管理模块接口
export function register(data) {
  return request({
    url: '/api/admin/register',
    method: 'post',
    data
  })
}
export function login(data) {
  return request({
    url: '/api/admin/login',
    method: 'post',
    data
  })
}
export function getInfo(data) {
  return request({
    url: '/api/admin/userInfo',
    method: 'get',
    params: data
  })
}
export function logout() {
  return request({
    url: '/api/admin/logout',
    method: 'get'
  })
}
export function getAdminUserList(data) {
  return request({
    url: '/api/admin/userList',
    method: 'get',
    params: data
  })
}
export function toogleAdminUserStatus(data) {
  return request({
    url: '/api/admin/toogleUserStatus',
    method: 'put',
    data
  })
}

// 用户管理模块接口
export function getUserList(data) {
  return request({
    url: '/api/admin/clientUserList',
    method: 'get',
    params: data
  })
}
export function daleteClientUser(data) {
  return request({
    url: '/api/admin/daleteClientUser',
    method: 'delete',
    data
  })
}
export function toogleClientUserStatus(data) {
  return request({
    url: '/api/admin/toogleClientUserStatus',
    method: 'put',
    data
  })
}
