/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-10-03 10:13:05
 * @LastEditTime: 2019-10-04 10:59:04
 * @LastEditors: Please set LastEditors
 */

export default {
  // 头部筛选过滤配置
  filterData: [{
    type: 'text',
    value: undefined,
    holder: '请输入账号',
    fieldName: 'username',
    width: 160
  }, {
    type: 'select',
    fieldName: 'status',
    value: undefined,
    options: [{
      value: undefined,
      label: '全部'
    }, {
      value: 'open',
      label: '正常'
    }, {
      value: 'close',
      label: '禁用'
    }],
    width: 120
  }, {
    type: 'select',
    fieldName: 'role',
    value: undefined,
    options: [{
      value: undefined,
      label: '全部'
    }, {
      value: 'super',
      label: '超级管理员'
    }, {
      value: 'normal',
      label: '普通用户'
    }],
    width: 120
  }, {
    type: 'button',
    data: [{
      value: '查询',
      type: 'primary',
      icon: 'el-icon-search',
      event: 'searchList'
    }, {
      value: '重置',
      type: 'info',
      icon: 'el-icon-delete',
      event: 'resetSearch'
    }]
  }],
  queryData: {
    page: 1,
    pageSize: 10
  },
  userListData: {},
  tableHeader: [{
    name: 'userId',
    prop: 'id'
  }, {
    name: '用户名',
    prop: 'username'
  }, {
    name: '手机号',
    prop: 'email'
  }, {
    name: '状态',
    prop: 'status'
  }, {
    name: '角色',
    prop: 'role'
  }, {
    name: '创建时间',
    prop: 'createdAt'
  }],
  slotConfig: [{
    name: '图标',
    soltName: 'avatar',
    width: '120px'
  }, {
    name: '开关',
    soltName: 'switch',
    width: '120px'
  }]
}
