<template>
  <div class="common-container">
    <div class="common-header">管理员列表</div>
    <common-filter-header
      :filter-data="filterData"
      @searchList="searchClientUserList"
      @resetSearch="resetSearch"
    />
    <common-table
      :table-header="tableHeader"
      :table-content="userListData"
      :slot-config="slotConfig"
      :get-format="getFormat"
      :page-no="queryData.page"
      :page-size="queryData.pageSize"
      :total-count="userListData.count"
      @currentChange="handleCurrentChange"
      @pageSizeChange="handleSizeChange"
    >
      <template slot="avatar" slot-scope="{scope}">
        <img
          v-if="scope.row.avatar"
          :src="scope.row.avatar"
          class="avatar-img"
          style="width:60px;height:60px;vertical-align: middle;"
        >
        <img
          v-else
          src="@/assets/images/default_avatar.png"
          title="默认图标"
          class="avatar-img"
          style="width:60px;height:60px;vertical-align: middle;"
        >
      </template>
      <template slot="switch" slot-scope="{scope}">
        <el-switch
          v-model="scope.row.status"
          active-value="open"
          inactive-value="close"
          active-color="#13ce66"
          inactive-color="#ff4949"
          @change="toogleUserStatus(scope.row)"
        />
      </template>
    </common-table>
  </div>
</template>

<script>
import { MessageBox, Loading } from 'element-ui'
import { getAdminUserList, toogleAdminUserStatus } from '@/api/user'
import indexTableConfig from './indexTableConfig.js'

export default {
  name: 'SystemUserList',
  data() {
    return {
      ...indexTableConfig
    }
  },
  watch: {
    filterData: {
      handler() {
        this.queryData = {
          page: 1,
          pageSize: 10,
          username: this.filterData[0].value,
          status: this.filterData[1].value,
          role: this.filterData[2].value
        }
      },
      deep: true
    }
  },
  created() {
    this.getClientUserList()
  },
  methods: {
    getClientUserList() {
      getAdminUserList(this.queryData).then(result => {
        if (result.statusCode === 200) {
          this.userListData = result.data
        } else {
          console.log(result.message)
        }
      })
    },
    searchClientUserList() {
      this.queryData.page = 1
      this.getClientUserList()
    },
    resetSearch() {
      this.filterData[0].value = undefined
      this.filterData[1].value = undefined
      this.filterData[2].value = undefined
    },
    handleSizeChange(val) {
      this.queryData.pageSize = val
      this.getClientUserList()
    },
    handleCurrentChange(val) {
      this.queryData.page = val
      this.getClientUserList()
    },
    toogleUserStatus(row) {
      var loading = Loading.service({ text: '加载中...' })
      toogleAdminUserStatus({
        id: row.id,
        status: row.status
      }).then(result => {
        loading.close()
        if (result.statusCode === 200) {
          this.$message({
            message: '操作成功',
            type: 'success'
          })
          this.getClientUserList()
        } else {
          this.$message({
            message: result.message,
            type: 'error'
          })
        }
      })
    },
    getFormat(row, column, cellValue, index) {
      var value = row[column.property]
      switch (column.label) {
        case '状态':
          return value === 'open' ? '正常' : '禁用'
        case '角色':
          return value === 'super'
            ? '超级管理员'
            : value === 'normal'
              ? '普通用户'
              : '未知状态'
        default:
          return value
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import "./index.scss";
</style>

