/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-10-03 10:13:05
 * @LastEditTime: 2019-10-04 10:59:04
 * @LastEditors: Please set LastEditors
 */

export default {
  // 头部筛选过滤配置
  filterData: [
    {
      type: 'timePicker',
      dateType: 'datetimerange',
      afterDays: 0,
      value: ['', ''],
      fieldName: ['startTimestamp', 'endTimestamp'],
      width: 400
    }, {
      type: 'text',
      value: undefined,
      holder: '请输入用户手机号',
      fieldName: 'mobile',
      width: 160
    }, {
      type: 'text',
      value: undefined,
      holder: '请输入用户昵称',
      fieldName: 'nickname',
      width: 160
    }, {
      type: 'select',
      fieldName: 'status',
      value: undefined,
      options: [
        {
          value: undefined,
          label: '全部'
        }, {
          value: 'open',
          label: '正常'
        }, {
          value: 'close',
          label: '禁用'
        }
      ],
      width: 120
    }, {
      type: 'button',
      data: [
        {
          value: '查询',
          type: 'primary',
          icon: 'el-icon-search',
          event: 'searchList'
        }, {
          value: '重置',
          type: 'info',
          icon: 'el-icon-delete',
          event: 'resetSearch'
        }
      ]
    }],
  queryData: {
    page: 1,
    pageSize: 10
  },
  userListData: {},
  // 表格操作按钮
  buttonList: [
    {
      name: '操作',
      width: 300,
      list: [{
        name: '用户详情',
        eventMethod: 'queryRelatedStock',
        type: 'primary',
        icon: 'el-icon-view'
      }, {
        name: '删除',
        eventMethod: 'deleteThemeOption',
        type: 'danger',
        icon: 'el-icon-delete'
      }]
    }
  ],
  tableHeader: [
    {
      name: 'userId',
      prop: 'id'
    }, {
      name: '昵称',
      prop: 'nickname'
    }, {
      name: '手机号',
      prop: 'mobile'
    }, {
      name: '图片',
      prop: 'avatar'
    }, {
      name: '状态',
      prop: 'status'
    }, {
      name: '创建时间',
      prop: 'createdAt'
    }, {
      name: '更新时间',
      prop: 'updatedAt'
    }
  ]
}
