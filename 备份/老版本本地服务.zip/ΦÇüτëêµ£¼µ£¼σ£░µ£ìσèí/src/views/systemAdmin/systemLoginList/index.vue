<template>
  <div class="common-container">
    <div class="common-header">用户列表</div>
    <common-filter-header
      :filter-data="filterData"
      @searchList="searchClientUserList"
      @resetSearch="resetSearch"
    />
    <common-table
      :table-header="tableHeader"
      :table-content="userListData"
      :button-config="buttonList"
      :page-no="queryData.page"
      :page-size="queryData.pageSize"
      :total-count="userListData.count"
      @currentChange="handleCurrentChange"
      @pageSizeChange="handleSizeChange"
    />
  </div>
</template>

<script>
import { getUserList } from '@/api/user'
import indexTableConfig from './indexTableConfig.js'

export default {
  name: 'SystemLoginList',
  data() {
    return {
      ...indexTableConfig
    }
  },
  watch: {
    filterData: {
      handler() {
        this.queryData = {
          page: 1,
          pageSize: 10,
          mobile: this.filterData[1].value,
          nickname: this.filterData[2].value,
          status: this.filterData[3].value
        }
        if (this.filterData[0].value) {
          this.queryData.startTimestamp = this.filterData[0].value[0] ? parseInt(this.filterData[0].value[0].getTime() / 1000) : undefined
          this.queryData.endTimestamp = this.filterData[0].value[1] ? parseInt(this.filterData[0].value[1].getTime() / 1000) : undefined
        }
      },
      deep: true
    }
  },
  created() {
    this.getClientUserList()
  },
  methods: {
    getClientUserList() {
      getUserList(this.queryData).then(result => {
        if (result.statusCode === 200) {
          this.userListData = result.data
        } else {
          console.log(result.message)
        }
      })
    },
    searchClientUserList() {
      this.queryData.page = 1
      this.getClientUserList()
    },
    resetSearch() {
      this.filterData[0].value = ['', '']
      this.filterData[1].value = undefined
      this.filterData[2].value = undefined
      this.filterData[3].value = undefined
      this.filterData[4].value = undefined
    },
    handleSizeChange(val) {
      this.queryData.pageSize = val
      this.getClientUserList()
    },
    handleCurrentChange(val) {
      this.queryData.page = val
      this.getClientUserList()
    },
    getFormat(row, column, cellValue, index) {
      var value = row[column.property]
      var reg = /\[(.+)\](.+)\[\/.+\]/
      switch (column.label) {
        // case '操作时间':
        //   return parseTime(value)
        case '旧值':
          return value || '无'
        case '扩展字段':
          return (function(value) {
            var arr = value.split(',')
            var result = []
            arr.forEach(item => {
              result.push(`${item.match(reg)[1]}:${item.match(reg)[2]}`)
            })
            return result.join(' | ')
          })(value)
        default:
          return value
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import "./index.scss";
</style>

