/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-10-03 10:13:05
 * @LastEditTime: 2019-10-04 10:59:04
 * @LastEditors: Please set LastEditors
 */

export default {
  // 头部筛选过滤配置
  filterData: [{
    type: 'timePicker',
    dateType: 'datetimerange',
    afterDays: 0,
    value: ['', ''],
    fieldName: ['startTimestamp', 'endTimestamp'],
    width: 400
  }, {
    type: 'text',
    value: undefined,
    holder: '请输入用户手机号',
    fieldName: 'mobile',
    width: 160
  }, {
    type: 'text',
    value: undefined,
    holder: '请输入用户昵称',
    fieldName: 'nickname',
    width: 160
  }, {
    type: 'select',
    fieldName: 'status',
    value: undefined,
    options: [{
      value: undefined,
      label: '全部'
    }, {
      value: 1,
      label: '正常'
    }, {
      value: 2,
      label: '冻结'
    }],
    width: 120
  }, {
    type: 'button',
    data: [{
      value: '查询',
      type: 'primary',
      icon: 'el-icon-search',
      event: 'searchList'
    }, {
      value: '重置',
      type: 'info',
      icon: 'el-icon-delete',
      event: 'resetSearch'
    }]
  }],
  queryData: {
    page: 1,
    pageSize: 10
  },
  userListData: {},
  // 表格操作按钮
  buttonList: [{
    name: '操作',
    width: 250,
    list: [{
      name: '用户详情',
      eventMethod: 'queryRelatedStock',
      type: 'primary',
      icon: 'el-icon-view'
    }, {
      name: '删除',
      eventMethod: 'deleteUser',
      type: 'danger',
      icon: 'el-icon-delete'
    }, {
      name: '冻结',
      eventMethod: 'changeUserStatus',
      type: 'warning',
      icon: 'el-icon-setting',
      onJudgeShow(item) {
        return item.status === 1
      }
    }, {
      name: '解冻',
      eventMethod: 'changeUserStatus',
      type: 'warning',
      icon: 'el-icon-setting',
      onJudgeShow(item) {
        return item.status === 2
      }
    }]
  }],
  tableHeader: [{
    name: 'userId',
    prop: 'userId'
  }, {
    name: '昵称',
    prop: 'nickname'
  }, {
    name: '手机号',
    prop: 'mobile',
    width: 120
  }, {
    name: '状态',
    prop: 'status'
  }, {
    name: '创建时间',
    prop: 'createdAt',
    width: 150
  }, {
    name: '更新时间',
    prop: 'updatedAt',
    width: 150
  }]
}
