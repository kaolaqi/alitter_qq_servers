<template>
  <div class="common-container">
    <div class="common-header">用户列表</div>
    <common-filter-header
      :filter-data="filterData"
      @searchList="searchClientUserList"
      @resetSearch="resetSearch"
    />
    <common-table
      :table-header="tableHeader"
      :table-content="userListData"
      :button-config="buttonList"
      :get-format="getFormat"
      :page-no="queryData.page"
      :page-size="queryData.pageSize"
      :total-count="userListData.count"
      @deleteUser="deleteUser"
      @changeUserStatus="changeUserStatus"
      @currentChange="handleCurrentChange"
      @pageSizeChange="handleSizeChange"
    />
  </div>
</template>

<script>
import { MessageBox, Loading } from 'element-ui'
import { getUserList, daleteClientUser, toogleClientUserStatus } from '@/api/user'
import indexTableConfig from './indexTableConfig.js'

export default {
  name: 'UserList',
  data() {
    return {
      ...indexTableConfig
    }
  },
  watch: {
    filterData: {
      handler() {
        this.queryData = {
          page: 1,
          pageSize: 10,
          mobile: this.filterData[1].value,
          nickname: this.filterData[2].value,
          status: this.filterData[3].value
        }
        if (this.filterData[0].value) {
          this.queryData.startTimestamp = this.filterData[0].value[0] ? this.filterData[0].value[0].getTime() : undefined
          this.queryData.endTimestamp = this.filterData[0].value[1] ? this.filterData[0].value[1].getTime() : undefined
        }
      },
      deep: true
    }
  },
  created() {
    this.getClientUserList()
  },
  methods: {
    getClientUserList() {
      getUserList(this.queryData).then(result => {
        if (result.statusCode === 200) {
          this.userListData = result.data
        } else {
          MessageBox({
            title: '提示',
            message: result.message || '请求错误',
            type: 'error',
            confirmButtonText: '关闭'
          })
        }
      })
    },
    searchClientUserList() {
      this.queryData.page = 1
      this.getClientUserList()
    },
    resetSearch() {
      this.filterData[0].value = ['', '']
      this.filterData[1].value = undefined
      this.filterData[2].value = undefined
      this.filterData[3].value = undefined
      this.filterData[4].value = undefined
    },
    handleSizeChange(val) {
      this.queryData.pageSize = val
      this.getClientUserList()
    },
    handleCurrentChange(val) {
      this.queryData.page = val
      this.getClientUserList()
    },

    deleteUser(item) {
      MessageBox({
        title: '提示',
        message: `此确定要删除 ${item.nickname}(${item.mobile}) 用户吗?`,
        type: 'warning',
        lockScroll: false,
        showCancelButton: true
      }).then(() => {
        var loading = Loading.service({ text: '加载中...' })
        daleteClientUser({
          id: item.id
        }).then(result => {
          loading.close()
          if (result.statusCode === 200) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.getClientUserList()
          } else {
            this.$message({
              message: result.message,
              type: 'error'
            })
          }
        })
      }).catch(() => {})
    },
    changeUserStatus(item) {
      var loading = Loading.service({ text: '加载中...' })
      toogleClientUserStatus({
        userId: item.userId,
        status: item.status === 1 ? 2 : 1
      }).then(result => {
        loading.close()
        if (result.statusCode === 200) {
          this.$message({
            message: '操作成功',
            type: 'success'
          })
          this.getClientUserList()
        } else {
          this.$message({
            message: result.message,
            type: 'error'
          })
        }
      })
    },
    getFormat(row, column, cellValue, index) {
      var value = row[column.property]
      switch (column.label) {
        case '状态':
          return value === 1 ? '正常' : '禁用'
        default:
          return value
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import "./index.scss";
</style>

